# CompressBinaryTable
 
## Basic Usage:

```console

cbt -i input_file -o output_file -c 

```

## Options:

```console

-i = input, required 
-o = output, required 
-c = compression 
-d = decompression 
-t = output type, either csv or tsv 
--override = to override output file if it exist 

```
